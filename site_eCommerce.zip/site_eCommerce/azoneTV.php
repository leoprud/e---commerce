<?php
	require_once('include/header.php');
?>

<div style="text-align: center;">
	<h2>"Hélas Polo Club" Mixtape</h2>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/mlndNtNhwIc" frameborder="0" allowfullscreen></iframe>

		<hr>

	<h2>The Dime Video</h2>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/JrCdpu6RHOs" frameborder="0" allowfullscreen></iframe>

		<hr>

	<h2>détériorer c ma passion</h2>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/Y0OJh5HsUNU" frameborder="0" allowfullscreen></iframe>

		<hr>

	<h2>Doble Christmas 2016</h2>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/L4nUGWscafg" frameborder="0" allowfullscreen></iframe>

		<hr>

	<h2>LA CRASSE</h2>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/cM1QWbi67As" frameborder="0" allowfullscreen></iframe>

		<hr>

	<h2>A SERIOUS VIDEO</h2>
		<iframe width="560" height="315" src="https://www.youtube.com/embed/noxtwaMbkcI" frameborder="0" allowfullscreen></iframe>

		<hr>

</div>

<?php 

require_once('include/footer.php');

?>