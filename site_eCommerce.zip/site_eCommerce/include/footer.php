			<footer class="col-xs-12" style="text-align: center;">
					<div class="col-xs-3"><a href="store.php"><h5>Copyright &copy; Azone 2017</h5></a></div>
					<div class="col-xs-3"><a href="register.php">Inscription</a></div>
					<div class="col-xs-3"><a href="connect.php">Connexion</a></div>
					<div class="col-xs-3"><a href="conditions.php">Conditions générales de ventes</a></div>
			</footer>

		</div>
	</body>

</html>

<?php 

?>